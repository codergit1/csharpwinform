﻿namespace Notes
{
    partial class Registxr
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registxr));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtPass2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.btnShowLogin = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnRegistxr = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.txtPass = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtUser = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.AllowDrop = true;
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.bunifuLabel1);
            this.bunifuGradientPanel1.Controls.Add(this.txtPass2);
            this.bunifuGradientPanel1.Controls.Add(this.btnShowLogin);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel2);
            this.bunifuGradientPanel1.Controls.Add(this.btnRegistxr);
            this.bunifuGradientPanel1.Controls.Add(this.txtPass);
            this.bunifuGradientPanel1.Controls.Add(this.txtUser);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel1);
            this.bunifuGradientPanel1.Controls.Add(this.pictureBox3);
            this.bunifuGradientPanel1.Controls.Add(this.pictureBox2);
            this.bunifuGradientPanel1.Controls.Add(this.pictureBox1);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.Orange;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Blue;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.Red;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.SeaShell;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1082, 821);
            this.bunifuGradientPanel1.TabIndex = 0;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = null;
            this.bunifuLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel1.ForeColor = System.Drawing.Color.Red;
            this.bunifuLabel1.Location = new System.Drawing.Point(340, 202);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(50, 27);
            this.bunifuLabel1.TabIndex = 10;
            this.bunifuLabel1.Text = "Error";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtPass2
            // 
            this.txtPass2.AcceptsReturn = false;
            this.txtPass2.AcceptsTab = false;
            this.txtPass2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtPass2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtPass2.BackColor = System.Drawing.Color.Transparent;
            this.txtPass2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtPass2.BackgroundImage")));
            this.txtPass2.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(45)))), ((int)(((byte)(145)))));
            this.txtPass2.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtPass2.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(38)))), ((int)(((byte)(157)))));
            this.txtPass2.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.txtPass2.BorderRadius = 35;
            this.txtPass2.BorderThickness = 1;
            this.txtPass2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtPass2.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPass2.DefaultText = "";
            this.txtPass2.FillColor = System.Drawing.Color.White;
            this.txtPass2.HideSelection = true;
            this.txtPass2.IconLeft = null;
            this.txtPass2.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.txtPass2.IconPadding = 10;
            this.txtPass2.IconRight = null;
            this.txtPass2.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.txtPass2.Location = new System.Drawing.Point(328, 455);
            this.txtPass2.MaxLength = 32767;
            this.txtPass2.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtPass2.Modified = false;
            this.txtPass2.Name = "txtPass2";
            this.txtPass2.PasswordChar = '\0';
            this.txtPass2.ReadOnly = false;
            this.txtPass2.SelectedText = "";
            this.txtPass2.SelectionLength = 0;
            this.txtPass2.SelectionStart = 0;
            this.txtPass2.ShortcutsEnabled = true;
            this.txtPass2.Size = new System.Drawing.Size(398, 66);
            this.txtPass2.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtPass2.TabIndex = 9;
            this.txtPass2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtPass2.TextMarginLeft = 5;
            this.txtPass2.TextPlaceholder = "confirm password";
            this.txtPass2.UseSystemPasswordChar = false;
            this.txtPass2.TextChange += new System.EventHandler(this.TxtPass2_TextChange);
            // 
            // btnShowLogin
            // 
            this.btnShowLogin.BackColor = System.Drawing.Color.Transparent;
            this.btnShowLogin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnShowLogin.BackgroundImage")));
            this.btnShowLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnShowLogin.ButtonText = "Login";
            this.btnShowLogin.ButtonTextMarginLeft = 0;
            this.btnShowLogin.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.btnShowLogin.DisabledFillColor = System.Drawing.Color.Gray;
            this.btnShowLogin.DisabledForecolor = System.Drawing.Color.White;
            this.btnShowLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F);
            this.btnShowLogin.ForeColor = System.Drawing.Color.White;
            this.btnShowLogin.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnShowLogin.IconPadding = 1;
            this.btnShowLogin.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnShowLogin.IdleBorderColor = System.Drawing.Color.DarkOrange;
            this.btnShowLogin.IdleBorderRadius = 35;
            this.btnShowLogin.IdleBorderThickness = 2;
            this.btnShowLogin.IdleFillColor = System.Drawing.Color.DarkOrchid;
            this.btnShowLogin.IdleIconLeftImage = null;
            this.btnShowLogin.IdleIconRightImage = null;
            this.btnShowLogin.Location = new System.Drawing.Point(577, 643);
            this.btnShowLogin.Name = "btnShowLogin";
            stateProperties1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties1.BorderRadius = 1;
            stateProperties1.BorderThickness = 1;
            stateProperties1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties1.IconLeftImage = null;
            stateProperties1.IconRightImage = null;
            this.btnShowLogin.onHoverState = stateProperties1;
            this.btnShowLogin.Size = new System.Drawing.Size(162, 51);
            this.btnShowLogin.TabIndex = 8;
            this.btnShowLogin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnShowLogin.Click += new System.EventHandler(this.BtnLogin_Click);
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Century Gothic", 7.875F);
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(256, 652);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(257, 24);
            this.bunifuCustomLabel2.TabIndex = 7;
            this.bunifuCustomLabel2.Text = "Already have Account?";
            // 
            // btnRegistxr
            // 
            this.btnRegistxr.BackColor = System.Drawing.Color.Transparent;
            this.btnRegistxr.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnRegistxr.BackgroundImage")));
            this.btnRegistxr.ButtonText = "Submit";
            this.btnRegistxr.ButtonTextMarginLeft = 0;
            this.btnRegistxr.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.btnRegistxr.DisabledFillColor = System.Drawing.Color.Gray;
            this.btnRegistxr.DisabledForecolor = System.Drawing.Color.White;
            this.btnRegistxr.Font = new System.Drawing.Font("Century Gothic", 5F);
            this.btnRegistxr.ForeColor = System.Drawing.Color.White;
            this.btnRegistxr.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnRegistxr.IconPadding = 10;
            this.btnRegistxr.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnRegistxr.IdleBorderColor = System.Drawing.Color.White;
            this.btnRegistxr.IdleBorderRadius = 35;
            this.btnRegistxr.IdleBorderThickness = 1;
            this.btnRegistxr.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.btnRegistxr.IdleIconLeftImage = null;
            this.btnRegistxr.IdleIconRightImage = null;
            this.btnRegistxr.Location = new System.Drawing.Point(436, 545);
            this.btnRegistxr.Name = "btnRegistxr";
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties2.BorderRadius = 1;
            stateProperties2.BorderThickness = 1;
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties2.IconLeftImage = null;
            stateProperties2.IconRightImage = null;
            this.btnRegistxr.onHoverState = stateProperties2;
            this.btnRegistxr.Size = new System.Drawing.Size(164, 60);
            this.btnRegistxr.TabIndex = 6;
            this.btnRegistxr.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnRegistxr.Click += new System.EventHandler(this.BunifuButton1_Click);
            // 
            // txtPass
            // 
            this.txtPass.AcceptsReturn = false;
            this.txtPass.AcceptsTab = false;
            this.txtPass.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtPass.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtPass.BackColor = System.Drawing.Color.Transparent;
            this.txtPass.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtPass.BackgroundImage")));
            this.txtPass.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.txtPass.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtPass.BorderColorHover = System.Drawing.Color.Fuchsia;
            this.txtPass.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.txtPass.BorderRadius = 35;
            this.txtPass.BorderThickness = 1;
            this.txtPass.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtPass.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPass.DefaultText = "";
            this.txtPass.FillColor = System.Drawing.Color.White;
            this.txtPass.HideSelection = true;
            this.txtPass.IconLeft = null;
            this.txtPass.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.txtPass.IconPadding = 10;
            this.txtPass.IconRight = null;
            this.txtPass.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.txtPass.Location = new System.Drawing.Point(328, 357);
            this.txtPass.MaxLength = 32767;
            this.txtPass.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtPass.Modified = false;
            this.txtPass.Name = "txtPass";
            this.txtPass.PasswordChar = '\0';
            this.txtPass.ReadOnly = false;
            this.txtPass.SelectedText = "";
            this.txtPass.SelectionLength = 0;
            this.txtPass.SelectionStart = 0;
            this.txtPass.ShortcutsEnabled = true;
            this.txtPass.Size = new System.Drawing.Size(398, 67);
            this.txtPass.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtPass.TabIndex = 5;
            this.txtPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtPass.TextMarginLeft = 5;
            this.txtPass.TextPlaceholder = "enter password";
            this.txtPass.UseSystemPasswordChar = false;
            this.txtPass.TextChange += new System.EventHandler(this.TxtPass_TextChange);
            // 
            // txtUser
            // 
            this.txtUser.AcceptsReturn = false;
            this.txtUser.AcceptsTab = false;
            this.txtUser.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtUser.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtUser.BackColor = System.Drawing.Color.Transparent;
            this.txtUser.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtUser.BackgroundImage")));
            this.txtUser.BorderColorActive = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.txtUser.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtUser.BorderColorHover = System.Drawing.Color.Fuchsia;
            this.txtUser.BorderColorIdle = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
            this.txtUser.BorderRadius = 35;
            this.txtUser.BorderThickness = 1;
            this.txtUser.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtUser.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUser.DefaultText = "";
            this.txtUser.FillColor = System.Drawing.Color.White;
            this.txtUser.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txtUser.HideSelection = true;
            this.txtUser.IconLeft = null;
            this.txtUser.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.txtUser.IconPadding = 10;
            this.txtUser.IconRight = null;
            this.txtUser.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.txtUser.Location = new System.Drawing.Point(328, 265);
            this.txtUser.MaxLength = 32767;
            this.txtUser.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtUser.Modified = false;
            this.txtUser.Name = "txtUser";
            this.txtUser.PasswordChar = '\0';
            this.txtUser.ReadOnly = false;
            this.txtUser.SelectedText = "";
            this.txtUser.SelectionLength = 0;
            this.txtUser.SelectionStart = 0;
            this.txtUser.ShortcutsEnabled = true;
            this.txtUser.Size = new System.Drawing.Size(398, 69);
            this.txtUser.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtUser.TabIndex = 4;
            this.txtUser.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtUser.TextMarginLeft = 5;
            this.txtUser.TextPlaceholder = "enter username";
            this.txtUser.UseSystemPasswordChar = false;
            this.txtUser.TextChange += new System.EventHandler(this.TxtUser_TextChange);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.bunifuCustomLabel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Constantia", 20F);
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(402, 77);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(234, 107);
            this.bunifuCustomLabel1.TabIndex = 3;
            this.bunifuCustomLabel1.Text = "Register";
            this.bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuCustomLabel1.Click += new System.EventHandler(this.BunifuCustomLabel1_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(991, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(88, 71);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.PictureBox3_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(3, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(88, 71);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 747);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(88, 71);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Registxr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Name = "Registxr";
            this.Size = new System.Drawing.Size(1082, 821);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnRegistxr;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtPass;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtUser;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnShowLogin;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtPass2;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
    }
}

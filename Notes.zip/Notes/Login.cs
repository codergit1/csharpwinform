﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Notes
{
    public partial class Login : UserControl
    {
        public Login()
        {
            if (Program.IsInDesignMode())
            {
                return;
            }
            InitializeComponent();
        }

        private void BunifuLabel2_Click(object sender, EventArgs e)
        {

        }

        private void PictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Close()
        {
           // throw new NotImplementedException();
        }

        private void BtnShowRegistxr_Click(object sender, EventArgs e)
        {
            Form1.mainInstance.ShowRegistxr();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            if (Validator.isValidName(txtUsername.Text) && Validator.isValidPassName(txtPassword.Text))
            {
                //check database and validate


                Form1.mainInstance.showRecord();
            }

        }

        private void TxtUsername_TextChange(object sender, EventArgs e)
        {
            txtUsername.IconRight = Form1.mainInstance.getValidatorImage(Validator.isValidName(txtUsername.Text));

        }

        private void TxtPassword_TextChange(object sender, EventArgs e)
        {
            txtPassword.IconRight = Form1.mainInstance.getValidatorImage(Validator.isValidPassName(txtPassword.Text));
        }
    }
}

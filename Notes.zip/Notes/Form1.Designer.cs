﻿namespace Notes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            Bunifu.UI.WinForms.BunifuAnimatorNS.Animation animation2 = new Bunifu.UI.WinForms.BunifuAnimatorNS.Animation();
            this.imageListValidatorIcons = new System.Windows.Forms.ImageList(this.components);
            this.bunifuTransition1 = new Bunifu.UI.WinForms.BunifuTransition(this.components);
            this.login2 = new Notes.Login();
            this.registxr2 = new Notes.Registxr();
            this.records1 = new Notes.Records();
            this.profile1 = new Notes.Profile();
            this.login1 = new Notes.Login();
            this.registxr1 = new Notes.Registxr();
            this.records2 = new Notes.Records();
            this.profile2 = new Notes.Profile();
            this.about1 = new Notes.About();
            this.bunifuFormDock1 = new Bunifu.UI.WinForms.BunifuFormDock();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.SuspendLayout();
            // 
            // imageListValidatorIcons
            // 
            this.imageListValidatorIcons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListValidatorIcons.ImageStream")));
            this.imageListValidatorIcons.TransparentColor = System.Drawing.Color.Transparent;
            this.imageListValidatorIcons.Images.SetKeyName(0, "checkmark_48px.png");
            this.imageListValidatorIcons.Images.SetKeyName(1, "close_window_48px.png");
            // 
            // bunifuTransition1
            // 
            this.bunifuTransition1.AnimationType = Bunifu.UI.WinForms.BunifuAnimatorNS.AnimationType.Scale;
            this.bunifuTransition1.Cursor = null;
            animation2.AnimateOnlyDifferences = true;
            animation2.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.BlindCoeff")));
            animation2.LeafCoeff = 0F;
            animation2.MaxTime = 1F;
            animation2.MinTime = 0F;
            animation2.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.MosaicCoeff")));
            animation2.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation2.MosaicShift")));
            animation2.MosaicSize = 0;
            animation2.Padding = new System.Windows.Forms.Padding(0, 0, 0, 0);
            animation2.RotateCoeff = 0F;
            animation2.RotateLimit = 0F;
            animation2.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.ScaleCoeff")));
            animation2.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.SlideCoeff")));
            animation2.TimeCoeff = 0F;
            animation2.TransparencyCoeff = 0F;
            this.bunifuTransition1.DefaultAnimation = animation2;
            // 
            // login2
            // 
            this.bunifuTransition1.SetDecoration(this.login2, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.login2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.login2.Location = new System.Drawing.Point(0, 0);
            this.login2.Name = "login2";
            this.login2.Size = new System.Drawing.Size(1082, 821);
            this.login2.TabIndex = 0;
            // 
            // registxr2
            // 
            this.bunifuTransition1.SetDecoration(this.registxr2, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.registxr2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.registxr2.Location = new System.Drawing.Point(0, 0);
            this.registxr2.Name = "registxr2";
            this.registxr2.Size = new System.Drawing.Size(1082, 821);
            this.registxr2.TabIndex = 1;
            // 
            // records1
            // 
            this.records1.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.bunifuTransition1.SetDecoration(this.records1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.records1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.records1.Location = new System.Drawing.Point(0, 0);
            this.records1.Name = "records1";
            this.records1.Size = new System.Drawing.Size(1082, 821);
            this.records1.TabIndex = 2;
            // 
            // profile1
            // 
            this.bunifuTransition1.SetDecoration(this.profile1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.profile1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.profile1.Location = new System.Drawing.Point(0, 0);
            this.profile1.Name = "profile1";
            this.profile1.Size = new System.Drawing.Size(1082, 821);
            this.profile1.TabIndex = 3;
            // 
            // login1
            // 
            this.bunifuTransition1.SetDecoration(this.login1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.login1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.login1.Location = new System.Drawing.Point(0, 0);
            this.login1.Name = "login1";
            this.login1.Size = new System.Drawing.Size(1082, 821);
            this.login1.TabIndex = 0;
            // 
            // registxr1
            // 
            this.bunifuTransition1.SetDecoration(this.registxr1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.registxr1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.registxr1.Location = new System.Drawing.Point(0, 0);
            this.registxr1.Name = "registxr1";
            this.registxr1.Size = new System.Drawing.Size(1082, 821);
            this.registxr1.TabIndex = 1;
            // 
            // records2
            // 
            this.records2.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.bunifuTransition1.SetDecoration(this.records2, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.records2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.records2.Location = new System.Drawing.Point(0, 0);
            this.records2.Name = "records2";
            this.records2.Size = new System.Drawing.Size(1082, 821);
            this.records2.TabIndex = 2;
            // 
            // profile2
            // 
            this.bunifuTransition1.SetDecoration(this.profile2, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.profile2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.profile2.Location = new System.Drawing.Point(0, 0);
            this.profile2.Name = "profile2";
            this.profile2.Size = new System.Drawing.Size(1082, 821);
            this.profile2.TabIndex = 3;
            // 
            // about1
            // 
            this.about1.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.bunifuTransition1.SetDecoration(this.about1, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.about1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.about1.Location = new System.Drawing.Point(0, 0);
            this.about1.Name = "about1";
            this.about1.Size = new System.Drawing.Size(1082, 821);
            this.about1.TabIndex = 4;
            // 
            // bunifuFormDock1
            // 
            this.bunifuFormDock1.AllowFormDragging = true;
            this.bunifuFormDock1.AllowFormDropShadow = true;
            this.bunifuFormDock1.AllowFormResizing = true;
            this.bunifuFormDock1.AllowHidingBottomRegion = true;
            this.bunifuFormDock1.AllowOpacityChangesWhileDragging = false;
            this.bunifuFormDock1.BorderOptions.BottomBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.BottomBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.BottomBorder.ShowBorder = true;
            this.bunifuFormDock1.BorderOptions.LeftBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.LeftBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.LeftBorder.ShowBorder = true;
            this.bunifuFormDock1.BorderOptions.RightBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.RightBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.RightBorder.ShowBorder = true;
            this.bunifuFormDock1.BorderOptions.TopBorder.BorderColor = System.Drawing.Color.Silver;
            this.bunifuFormDock1.BorderOptions.TopBorder.BorderThickness = 1;
            this.bunifuFormDock1.BorderOptions.TopBorder.ShowBorder = true;
            this.bunifuFormDock1.ContainerControl = this;
            this.bunifuFormDock1.DockingIndicatorsColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(215)))), ((int)(((byte)(233)))));
            this.bunifuFormDock1.DockingIndicatorsOpacity = 0.5D;
            this.bunifuFormDock1.DockingOptions.DockAll = true;
            this.bunifuFormDock1.DockingOptions.DockBottomLeft = true;
            this.bunifuFormDock1.DockingOptions.DockBottomRight = true;
            this.bunifuFormDock1.DockingOptions.DockFullScreen = true;
            this.bunifuFormDock1.DockingOptions.DockLeft = true;
            this.bunifuFormDock1.DockingOptions.DockRight = true;
            this.bunifuFormDock1.DockingOptions.DockTopLeft = true;
            this.bunifuFormDock1.DockingOptions.DockTopRight = true;
            this.bunifuFormDock1.FormDraggingOpacity = 0.9D;
            this.bunifuFormDock1.ParentForm = this;
            this.bunifuFormDock1.ShowCursorChanges = true;
            this.bunifuFormDock1.ShowDockingIndicators = true;
            this.bunifuFormDock1.TitleBarOptions.AllowFormDragging = true;
            this.bunifuFormDock1.TitleBarOptions.BunifuFormDock = this.bunifuFormDock1;
            this.bunifuFormDock1.TitleBarOptions.DoubleClickToExpandWindow = true;
            this.bunifuFormDock1.TitleBarOptions.TitleBarControl = null;
            this.bunifuFormDock1.TitleBarOptions.UseBackColorOnDockingIndicators = false;
            this.bunifuFormDock1.FormDragging += new System.EventHandler<Bunifu.UI.WinForms.BunifuFormDock.FormDraggingEventArgs>(this.BunifuFormDock1_FormDragging);
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this;
            this.bunifuDragControl1.Vertical = true;
            // 
            // Form1
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1082, 821);
            this.Controls.Add(this.login1);
            this.Controls.Add(this.profile2);
            this.Controls.Add(this.records2);
            this.Controls.Add(this.registxr1);
            this.Controls.Add(this.about1);
            this.bunifuTransition1.SetDecoration(this, Bunifu.UI.WinForms.BunifuTransition.DecorationType.None);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ImageList imageListValidatorIcons;
        private Bunifu.UI.WinForms.BunifuTransition bunifuTransition1;
        private Bunifu.UI.WinForms.BunifuFormDock bunifuFormDock1;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Login login2;
        private Registxr registxr2;
        private Records records1;
        private Profile profile1;
        private Login login1;
        private Registxr registxr1;
        private Records records2;
        private Profile profile2;
        private About about1;
    }
}


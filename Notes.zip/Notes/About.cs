﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Notes
{
    public partial class About : UserControl
    {
        public About()
        {
            InitializeComponent();
        }

        private void BunifuFlatButton1_Click(object sender, EventArgs e)
        {
            Form1.mainInstance.showProfile();
        }

        private void BunifuFlatButton2_Click(object sender, EventArgs e)
        {
            Form1.mainInstance.showRecord();
        }

        private void BunifuCustomLabel3_Click(object sender, EventArgs e)
        {

        }
    }
}

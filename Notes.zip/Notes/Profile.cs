﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Notes
{
    public partial class Profile : UserControl
    {
        public Profile()
        {
            if (Program.IsInDesignMode())
            {
                return;
            }
            InitializeComponent();
        }

        private void BtnMnu_Click(object sender, EventArgs e)
        {
            if (pnlMainMenu.Width == 110)
            {
                pnlMainMenu.Visible = false;
                pnlMainMenu.Width = 393;
                PanelAnimator.ShowSync(pnlMainMenu);
                LogoAnimator.ShowSync(btnMnu);
            }
            else
            {
                LogoAnimator.ShowSync(btnMnu);
                pnlMainMenu.Visible = false;

                //pictureBox1.Visible = true;
                pnlMainMenu.Width = 110;
                PanelAnimator.ShowSync(pnlMainMenu);
            }
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Close()
        {
            throw new NotImplementedException();
        }

     /**  private void BunifuButton1_Click(object sender, EventArgs e)
        {
            Form1.mainInstance.showLogin();
        }
    **/
        private void Profile_Load(object sender, EventArgs e)
        {

        }

        private void BunifuFlatButton2_Click(object sender, EventArgs e)
        {
            Form1.mainInstance.showRecord();
        }

        private void BunifuFlatButton3_Click(object sender, EventArgs e)
        {
            Form1.mainInstance.showAbout();
        }

        private void BunifuButton1_Click_1(object sender, EventArgs e)
        {
            Form1.mainInstance.showLogin();
        }
    }
}

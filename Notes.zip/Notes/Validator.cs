﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Notes
{
    class Validator
    {
        internal static bool isValidName(string text)
        {
            if (text.Contains(" "))
            {
                return false;
            }

            //Check if username is taken in database


            return text.Trim().Length > 5;
        }

        internal static bool isValidPassName(string text)
        {
            if (text.Contains(" "))
            {
                return false;
            }
            return text.Trim().Length > 5;
        }
    }
}

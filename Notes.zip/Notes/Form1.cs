﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Notes;

namespace Notes
{
    public partial class Form1 : Form
    {
        public static Form1 mainInstance = null;
       

        public Form1()
        {
            mainInstance = this;

            InitializeComponent();

            //making form draggable
            //attach controls to capture drag events

            bunifuFormDock1.SubscribeControlsToDragEvents(new Control[]
            {
                login1,
                registxr1,
                profile2,
                records2,
                about1,
            }, false);
        }

        public Image getValidatorImage(bool Valid)
        {
            if (Valid)
            {
                return imageListValidatorIcons.Images[0];
            }
            return imageListValidatorIcons.Images[1];
        }
        private void Registxr1_Load(object sender, EventArgs e)
        {
            //
        }

        internal void showRecord()
        {
            //show Records tab 
            records2.Visible = false;
            records2.BringToFront();
            bunifuTransition1.ShowSync(records2);
        }

        internal void showLogin()
        {
            //show Login tab
          login1.Visible = false;
           login1.BringToFront();
           bunifuTransition1.ShowSync(login1);
             
             

        }

        internal void ShowRegistxr()
        {
            //show Register tab
            registxr1.Visible = false;
            registxr1.BringToFront();
           bunifuTransition1.ShowSync(registxr1);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        internal void showProfile()
        {
            //show Records tab 
            profile2.Visible = false;
            profile2.BringToFront();
            bunifuTransition1.ShowSync(profile2);
        }

        internal void showAbout()
        {
            about1.Visible = false;
            about1.BringToFront();
            bunifuTransition1.ShowSync(about1);
        }

        private void BunifuFormDock1_FormDragging(object sender, Bunifu.UI.WinForms.BunifuFormDock.FormDraggingEventArgs e)
        {

        }
    }
}

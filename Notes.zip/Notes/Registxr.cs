﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Notes
{
    public partial class Registxr : UserControl
    {
        public Registxr()
        {
            if (Program.IsInDesignMode())
            {
                return;
            }
            InitializeComponent();
        }

        private void BunifuCustomLabel1_Click(object sender, EventArgs e)
        {

        }

        private void BunifuButton1_Click(object sender, EventArgs e)
        {
            if (!Validator.isValidName(txtUser.Text))
            {
                return;
            }
            if (!Validator.isValidPassName(txtPass.Text) && txtPass.Text==txtPass2.Text)
            {
                return;
            }
            //Success Validation

            //Insert DB and Load Login

            //Loadlogin
            Form1.mainInstance.showLogin();

        }

        private void PictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Close()
        {
           // throw new NotImplementedException();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            Form1.mainInstance.showLogin();
        }

        private void TxtUser_TextChange(object sender, EventArgs e)
        {
            if (Validator.isValidName(txtUser.Text))
            {
                txtUser.IconRight = Form1.mainInstance.getValidatorImage(Validator.isValidName(txtUser.Text));
                
            }
        }

        private void TxtPass_TextChange(object sender, EventArgs e)
        {
            //if (!Validator.isValidName(txtUser.Text))
           // {
                txtPass.IconRight = Form1.mainInstance.getValidatorImage(Validator.isValidPassName(txtPass.Text));
                
            //}
        }

        private void TxtPass2_TextChange(object sender, EventArgs e)
        {
            txtPass2.IconRight = Form1.mainInstance.getValidatorImage(txtPass.Text==txtPass2.Text);
        }

        /**
private void Close() 
{
   throw new NotImplementedException();
}**/
    }
}
